Hebrew (SIL) keyboard
==============

©Martin Z

Version 1.0

Description
-----------

This keyboard is designed for Biblical Hebrew. It provides all Hebrew consonants, vowels, and cantilations. It follows the mapping of the [Biblical Hebrew (SIL) keyboard](https://www.sbl-site.org/Fonts/BiblicalHebrewSILManual.pdf).

In addition, the "Ctrl" layer contains all consonants and vowels. It is sufficient in most typing cases. The "Ctrl + Shift" layer marks some ambigous signs, such as Qamets and Qamets Hatuph. It outputs the same results as the "Ctrl" layer.


Supported Platforms
-------------------
 * iPhone
 * iPad
 * Android phone
 * Android tablet
 * Mobile devices
 * Tablet devices

