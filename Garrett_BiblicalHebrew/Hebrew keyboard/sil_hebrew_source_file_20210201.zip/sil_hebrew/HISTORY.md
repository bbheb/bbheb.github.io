Hebrew (SIL) Change History
====================
1.1 (2021-02-01)
Base mark added for the display of the vowels and contilations. A few non-RTL signs may not have ideal display on iOS or android divices. But they do not affect typing.

1.0 (2021-01-27)
Hebrew (SIL) keyboard for mobile and tablet devices.
----------------
* Created by Martin Z
