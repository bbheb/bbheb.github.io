var x = document.querySelectorAll('.pull-left label');
	var i;
	for (i = 0; i < x.length; i++) {
	  x[i].style.fontFamily = "Times New Roman";
	  x[i].style.fontSize = "30px";
	}
